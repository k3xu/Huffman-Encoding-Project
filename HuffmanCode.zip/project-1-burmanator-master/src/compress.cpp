/**
 * TODO: Compress
 *
 * Author: David Jasuan and Kody Xu
 */
#include <cxxopts.hpp>
#include <fstream>
#include <iostream>
#include <sstream> /*ask*/
#include <vector>  /*ask*/

#include "FileUtils.hpp"
#include "HCNode.hpp"
#include "HCTree.hpp"

/* TODO: add pseudo compression with ascii encoding and naive header
 * (checkpoint) */
void pseudoCompression(const string& inFileName, const string& outFileName) {
    /*use helper method to read in freqs*/

    ifstream inFile;
    inFile.open(inFileName, ios::binary);

    /*initialize freqs*/
    vector<unsigned int> freqs;

    for (int i = 0; i < 256; i++) {
        freqs.push_back(0);
    }

    char input;
    while ((input = inFile.get()) != EOF) {
        if ((0 <= (unsigned int)input) && ((unsigned int)input < 256)) {
            freqs[(byte)input]++;
        }
    }

    HCTree tree;
    tree.build(freqs);
    /*call helper method that will send send an outstreams*/
    ofstream outFile;
    outFile.open(outFileName, ios::binary);
    /*for loop through each char in the textToEncode- and we will return it
     * through outsream*/
    for (int freqIndex = 0; freqIndex < 256; freqIndex++) {
        outFile << freqs[freqIndex] << "\n";
    }
    inFile.clear();                  /*DOES THIS WORK*/
    inFile.seekg(0, std::ios::beg);  // flush could work too
    while ((input = inFile.get()) != EOF) {
        tree.encode((byte)input,
                    outFile); /*HELP!!!!! or unsigend char??? OR BYTE*/
    }
    inFile.close();
    outFile.close();
}

void binary(unsigned int n, BitOutputStream out) {
    /* step 1 */
    if (n > 1) {
        binary(n / 2, out);
    }
    /* step 2 */
    unsigned int modded = n % 2;
    out.writeBit(modded);
}

/**
 * records the tree in post trasversal order
 * gets the symbol, gets the binary number and tosses it to the BitOutputStream
 */
void recordTree(HCNode* node, unsigned int i, BitOutputStream out) {
    if (node->c0 != 0) {
        recordTree(node->c0, 0, out);
    }
    if (node->c1 != 0) {
        recordTree(node->c1, 1, out);
    }
    out.writeBit(i);
    binary((unsigned int)node->symbol, out);
}

/* TODO: True compression with bitwise i/o and small header (final) */
void trueCompression(const string& inFileName, const string& outFileName) {
    /*READ IN THE FILE*/
    ifstream theFile;
    theFile.open(inFileName, ios::binary);

    /*initialize frequency */
    vector<unsigned int> freqs;
    for (int i = 0; i < 256; i++) {
        freqs.push_back(0);
    }

    /*read in input --- DOUBLE CHECK WITH TUTOR -- IF THIS IS THE PART THAT MADE
     * US FAIL FILE_4*/
    unsigned int nodeCount = 0;
    while (1) {
        byte nextChar = theFile.get();
        if (theFile.eof()) break;
        if ((0 <= nextChar) && (nextChar < 256)) {
            freqs[(unsigned int)nextChar]++;
            nodeCount++;
        }
    }

    /*build the tree*/
    HCTree tree;
    tree.build(freqs);

    /*open BitOutputStream*/
    ofstream outTheFile;
    outTheFile.open(outFileName);
    BitOutputStream out(outTheFile, 4000);

    binary(nodeCount, out);
    out.flush();

    HCNode* startNode = tree.getRoot();
    recordTree(startNode, 0, out);

    theFile.clear();
    theFile.seekg(0, std::ios::beg);

    /*go through each letter and encode it*/
    while (1) {
        byte nextChar = theFile.get();
        if (theFile.eof()) break;
        tree.encode(nextChar, out);
    }

    /*save the tree!!!! ---- ASK TUTOR IS WE CAN MAKE TREE'S MEMBER VARIABLES_
     * PUBLIC, if not how can we get access of the root, can we add methods into
     * the HCTree??*/

    out.flush();
    theFile.close();
    outTheFile.close();
}

/* Main program that runs the compression */
int main(int argc, char* argv[]) {
    cxxopts::Options options(argv[0],
                             "Compresses files using Huffman Encoding");
    options.positional_help("./path_to_input_file ./path_to_output_file");

    bool isAsciiOutput = false;
    string inFileName, outFileName;
    options.allow_unrecognised_options().add_options()(
        "ascii", "Write output in ascii mode instead of bit stream",
        cxxopts::value<bool>(isAsciiOutput))(
        "input", "", cxxopts::value<string>(inFileName))(
        "output", "", cxxopts::value<string>(outFileName))(
        "h,help", "Print help and exit");

    options.parse_positional({"input", "output"});
    auto userOptions = options.parse(argc, argv);

    if (userOptions.count("help") || !FileUtils::isValidFile(inFileName) ||
        outFileName.empty()) {
        cout << options.help({""}) << std::endl;
        return 0;
    }

    // if original file is empty, output empty file
    if (FileUtils::isEmptyFile(inFileName)) {
        ofstream outFile;
        outFile.open(outFileName, ios::out);
        outFile.close();
        return 0;
    }

    if (isAsciiOutput) {
        pseudoCompression(inFileName, outFileName);
    } else {
        trueCompression(inFileName, outFileName);
    }

    return 0;
}