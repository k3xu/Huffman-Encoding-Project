/**
 * TODO: file header
 *
 * Author:
 */
#include <cxxopts.hpp>
#include <fstream>
#include <iostream>
#include <unordered_map>

#include "FileUtils.hpp"
#include "HCNode.hpp"
#include "HCTree.hpp"

/*helps compression read in from lines 0 to 256*/
vector<unsigned int> readInHelper(istream& inFile) {
    vector<unsigned int> freqs;
    string input;

    int counter = 0;
    while (counter != 256) {
        unsigned int put;
        /*TO GO OR NOT TO GO, TO THE NEXT LINE*/

        std::getline(inFile, input);
        put = (unsigned int)std::stoi(input);
        // cout << counter << "    " << put << "\n\n";
        freqs.push_back(put);
        counter++;
        /**/
    }

    return freqs;
}

/* TODO: Pseudo decompression with ascii encoding and naive header (checkpoint)
 */
void pseudoDecompression(const string& inFileName, const string& outFileName) {
    /*use helper method to read in freqs*/
    ifstream inFile;
    inFile.open(inFileName);
    vector<unsigned int> freqs = readInHelper(inFile);
    HCTree tree;
    /*build the tree*/
    tree.build(freqs);

    ofstream outFile;
    outFile.open(outFileName);

    while (inFile.peek() != EOF) {
        // output = (unsigned char)inFile.get();
        char output;
        output = tree.decode(inFile);

        if (inFile.eof()) break;
        outFile << output;
        // outputString = outputString + (char)output;
    }

    inFile.close();
    outFile.close();
    /**
     * figure out a way to create a method that reads in from cin for
     * 256 lines and saves into a vector, need it for both compress
     * and uncompress
     *
     * last line needs to be read in as a string for compress
     *
     * last line needs to be read in byte by byte by decode which
     * returns the byte that needs to be printed into the outstream.
     */
}

int combineNumber(vector<unsigned int> vec) {
    int myNumInInteger = 0;
    int baseOfMyNumInVector = 10;
    for (int i : vec) {
        myNumInInteger = myNumInInteger * baseOfMyNumInVector + i;
    }
    return myNumInInteger;
}
/* TODO: True decompression with bitwise i/o and small header (final) */
void trueDecompression(const string& inFileName, const string& outFileName) {
    /*OPEN FILE*/
    ifstream inFile;
    ofstream outFile;
    inFile.open(inFileName, ios::binary);
    outFile.open(outFileName);

    /*open a bitInstream*/
    BitInputStream in(inFile, 4000);

    // use vector buffer
    vector<unsigned int> countNode;
    for (int i = 0; i < 8; i++) {
        unsigned int nextBit = in.readBit();
        if (in.eof()) break;
        unsigned char bit = (nextBit == 0) ? '0' : '1';
        countNode.push_back(bit - '0');
    }
    int Nodes = combineNumber(countNode);

    vector<unsigned int> parent;
    vector<unsigned char> code;
    unsigned int nextBit;
    unsigned char bit;
    for (int j = 0; j < Nodes; j++) {
        /*parent or children*/
        nextBit = in.readBit();
        if (in.eof()) break;
        bit = (nextBit == 0) ? '0' : '1';
        parent.push_back(bit - '0');
        /*ascii*/
        nextBit = in.readBit();
        if (in.eof()) break;
        bit = (nextBit == 0) ? '0' : '1';
        code.push_back(bit);
    }

    HCTree tree;
    tree.makeTheTreeGreatAgain(parent, code);

    vector<unsigned char> msg;
    while (1) {
        /*read in the bit*/
        unsigned int nextBit = in.readBit();
        /*when it gets to eof, it will break*/
        if (in.eof()) break;
        /*store the first of every 8 bit*/
        int encoded_msg = (nextBit == 0) ? '0' : '1';
        msg.push_back(encoded_msg);
    }

    vector<unsigned char> decoded_msg;
    for (int i = 0; i < msg.size(); i++) {
        decoded_msg.push_back(tree.decode(in));
    }
    outFile.write((const char*)&decoded_msg[0], decoded_msg.size());
    inFile.close();
    outFile.close();
}

/* Main program that runs the decompression */
int main(int argc, char* argv[]) {
    cxxopts::Options options(argv[0],
                             "Uncompresses files using Huffman Encoding");
    options.positional_help(
        "./path_to_compressed_input_file ./path_to_output_file");

    bool isAscii = false;
    string inFileName, outFileName;
    options.allow_unrecognised_options().add_options()(
        "ascii", "Read input in ascii mode instead of bit stream",
        cxxopts::value<bool>(isAscii))("input", "",
                                       cxxopts::value<string>(inFileName))(
        "output", "", cxxopts::value<string>(outFileName))(
        "h,help", "Print help and exit.");

    options.parse_positional({"input", "output"});
    auto userOptions = options.parse(argc, argv);

    if (userOptions.count("help") || !FileUtils::isValidFile(inFileName) ||
        outFileName.empty()) {
        cout << options.help({""}) << std::endl;
        exit(0);
    }

    // if compressed file is empty, output empty file
    if (FileUtils::isEmptyFile(inFileName)) {
        ofstream outFile;
        outFile.open(outFileName);
        outFile.close();
        exit(0);
    }

    if (isAscii) {
        pseudoDecompression(inFileName, outFileName);
    } else {
        trueDecompression(inFileName, outFileName);
    }

    return 0;
}
