#ifndef HCTREE_HPP
#define HCTREE_HPP

#include <fstream>
#include <queue>
#include <vector>

#include "BitInputStream.hpp"
#include "BitOutputStream.hpp"
#include "HCNode.hpp"

using namespace std;

class HCTree {
  private:
    HCNode* root;  // the root of HCTree -----ASK TA IS WE CAN MAKE  THIS PUBLIC
    vector<HCNode*> leaves;  // a vector storing pointers to all leaf HCNodes

  public:
    /* TODO: Initializes a new empty HCTree.*/
    HCTree() {
        root = NULL;
        leaves.resize(256, 0);
    }

    ~HCTree();

    void build(const vector<unsigned int>& freqs);

    void encode(byte symbol, BitOutputStream& out) const;

    void encodeHelper(HCNode node, byte symbol, ostream& out) const;

    void encode(byte symbol, ostream& out) const;

    byte decode(BitInputStream& in) const;

    byte decode(istream& in) const;

    void makeTheTreeGreatAgain(vector<unsigned int> parent,
                               vector<unsigned char> code);

    HCNode* getRoot() const { return root; }
};

#endif  // HCTREE_HPP
