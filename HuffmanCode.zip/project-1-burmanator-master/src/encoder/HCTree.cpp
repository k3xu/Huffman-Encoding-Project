#include "HCTree.hpp"

#include <algorithm>
#include <queue>
#include <string> /*check with tutor*/
#include <vector>

void clearOx(HCNode* node) {
    /*if there is a left Node, go left*/

    if (node == NULL) {
        return;
    }
    if (node->c0 != 0) {
        clearOx(node->c0);
    }
    /*if there is a right Node, go right*/
    if (node->c1 != 0) {
        clearOx(node->c1);
    }
    /*then delete*/
    delete node;
}

/* TODO: Delete all objects on the heap to avoid memory leaks. */
HCTree::~HCTree() { clearOx(root); }

/**
 * TODO: Build the HCTree from the given frequency vector. You can assume the
 * vector must have size 256 and each value at index i represents the frequency
 * of char with ASCII value i. Only non-zero frequency symbols should be used to
 * build the tree. The leaves vector must be updated so that it can be used in
 * encode() to improve performance.
 *
 * When building the HCTree, you should use the following tie-breaking rules to
 * match the output from reference solution in checkpoint:
 *
 *    1. HCNode with lower count should have higher priority. If count is the
 * same, then HCNode with a larger ascii value symbol should have higher
 * priority. (This should be already defined properly in the comparator in
 * HCNode.hpp)
 *    2. When popping two highest priority nodes from PQ, the higher priority
 * node will be the ‘c0’ child of the new parent HCNode.
 *    3. The symbol of any parent node should be taken from its 'c0' child.
 */
void HCTree::build(const vector<unsigned int>& freqs) {
    /* for each of the freqs create a forrest of tree*/
    int counter = 0;
    std::priority_queue<HCNode*, std::vector<HCNode*>, HCNodePtrComp> forest;
    for (unsigned int i = 0; i < 256; i++) {
        /*if the frequency of the ascii is more than one*/
        if (freqs[i] > 0) {
            /*if any frequency is show - counter many- times*/
            counter++;
            /*create a HCNode for this*/
            HCNode* newNode = new HCNode(freqs[i], (unsigned char)i, 0, 0, 0);
            leaves[i] = newNode;
            forest.push(newNode);
        }
    }

    /*THIS ATTEMPTS TO HANDLE THE EDGE CASE OF ONE BYTE INPUT*/

    /*edge case- case where there is only one node*/
    if (counter == 1) {
        /*set the real Node's parent to dummy*/
        HCNode* newNode = forest.top();
        forest.pop();
        /*create a dummy HCNode with no data*/
        HCNode* dummyNode =
            new HCNode(newNode->count, newNode->symbol, newNode, 0);

        newNode->p = dummyNode;
        /*set dummy to root*/

        root = dummyNode;
    }
    /*ENDS HERE*/

    else {
        /*sort the freqs*/
        while (forest.size() > 1) {
            // std::sort(forest.top(), forest.top() + forest.size(), comp);
            /*the first two element*/
            HCNode* first = forest.top();
            forest.pop();
            HCNode* second = forest.top();
            forest.pop();
            HCNode* parentNode = new HCNode(first->count + second->count,
                                            first->symbol, first, second, 0);
            first->p = parentNode;
            second->p = parentNode;
            forest.push(parentNode);
            root = parentNode;
        }
    }
}

/**
 * Make the tree again
 *
 *
 *
 *
 */
void HCTree::makeTheTreeGreatAgain(vector<unsigned int> parent,
                                   vector<unsigned char> code) {
    int sizeOfTree = parent.size();
    HCNode* parentNode;
    for (unsigned int i = sizeOfTree - 1; i >= 0; i--) {
        /*first one*/
        if (i == sizeOfTree - 1) {
            HCNode* newNode = new HCNode(0, code[i], 0, 0, 0);
            root = newNode;
            parentNode = newNode;
        } else {
            /*left child*/
            unsigned char parentRel = (unsigned char)parent[i];
            if (parentRel == '0') {
                HCNode* newNode = new HCNode(0, code[i], 0, 0, parentNode);
                parentNode->c0 = newNode;
            }
            /*right Child*/
            else {
                HCNode* newNode = new HCNode(0, code[i], 0, 0, parentNode);
                parentNode->c0 = newNode;
            }
        }
    }
}

/**
 * TODO: Write the encoding bits of the given symbol to the ostream. You should
 * write each encoding bit as ascii char either '0' or '1' to the ostream. You
 * must not perform a comprehensive search to find the encoding bits of the
 * given symbol, and you should use the leaves vector instead to achieve
 * efficient encoding. For this function to work, build() must be called before
 * to create the HCTree.
 */
void HCTree::encode(byte symbol, BitOutputStream& out) const {
    HCNode* currNode;

    /*iterate through leaves to find the node that has the symbol are
     * looking for*/
    currNode = leaves[symbol];

    /* traverse up, if we went up through the parent's left child, 0 , right
     * 1 , and we reverse */

    while (currNode != root) {
        HCNode* lastNode;
        /*lastNode*/
        lastNode = currNode;
        /*go up*/
        currNode = currNode->p;
        /*left child?*/
        if (currNode->c0 == lastNode) {
            out.writeBit(0);
            out.flush();
        } else {
            /*right child*/
            out.writeBit(1);
            out.flush();
        }
    }
}

/**
 * TODO: Write the encoding bits of the given symbol to ostream. You should
 * write each encoding bit as ascii char either '0' or '1' to the ostream.
 * You must not perform a comprehensive search to find the encoding bits of
 * the given symbol, and you should use the leaves vector instead to achieve
 * efficient encoding. For this function to work, build() must have been
 * called beforehand to create the HCTree.
 */
void HCTree::encode(byte symbol, ostream& out) const {
    // encodeHelper(*root, symbol, out);
    /**
     * when you go up, find am i left or right child- left 0, right 1
     **/
    /*find the node in leaves that have the symbol*/
    HCNode* currNode;

    /*iterate through leaves to find the node that has the symbol are
     * looking for*/
    currNode = leaves[symbol];

    /* traverse up, if we went up through the parent's left child, 0 , right
     * 1 , and we reverse */

    string outStr;
    while (currNode != root) {
        HCNode* lastNode;
        /*lastNode*/
        lastNode = currNode;
        /*go up*/
        currNode = currNode->p;
        /*left child?*/
        if (currNode->c0 == lastNode) {
            outStr = "0" + outStr;
        } else {
            /*right child*/
            outStr = "1" + outStr;
        }
    }
    out << outStr;
    return;
    // }
}
/**
 * TODO: Decode the sequence of bits (represented as a char of either '0' or
 * '1') from the istream to return the coded symbol. For this function to
 * work, build() must have been called beforehand to create the HCTree.
 */
byte HCTree::decode(BitInputStream& in) const {
    /*read the whole instream into code*/
    // std::string code(std::istreambuf_iterator<char>(in), {}); /*EITHER THIS*/

    /*start from currNode which is root*/
    HCNode* currNode = root;
    vector<unsigned char> bitsBuf;
    while ((currNode->c0 != 0 || currNode->c1 != 0)) {
        unsigned int nextBit = in.readBit();
        if (in.eof()) break;

        if (nextBit == 0) {
            currNode = currNode->c0;
        } else if (nextBit == 1) {
            /*other wise go right*/
            currNode = currNode->c1;
        }
    }
    //}
    return currNode->symbol;
}

/**
 * TODO: Decode the sequence of bits (represented as char of either '0' or
 * '1') from istream to return the coded symbol. For this function to work,
 * build() must have been called beforehand to create the HCTree.
 */
byte HCTree::decode(istream& in) const {
    /*

    /*read the whole instream into code*/
    // std::string code(std::istreambuf_iterator<char>(in), {}); /*EITHER THIS*/

    /*start from currNode which is root*/
    HCNode* currNode = root;

    while ((currNode->c0 != 0 || currNode->c1 != 0)) {
        unsigned char input;
        input = in.get();
        if (input == EOF) {
            break;
        }
        if (input == '0') {
            currNode = currNode->c0;
        } else if (input == '1') {
            /*other wise go right*/
            currNode = currNode->c1;
        }
    }
    //}
    return currNode->symbol;
}
