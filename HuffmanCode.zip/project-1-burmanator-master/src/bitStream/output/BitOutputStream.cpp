#include "BitOutputStream.hpp"

/**
 * TODO: Write the part of the buffer that was written by the user to the output
 * stream, and then clear the buffer to allow further use. You may use fill() to
 * zero-fill the buffer.
 *
 * Note: don’t flush the ostream here, as it is an extremely slow operation that
 * may cause a timeout.
 */
void BitOutputStream::flush() {
    /*flus the buffer*/
    out.write(buf, 1);
    /*clear buffer and bit counter*/
    nbits = 0;
    /*clear the buffer*/
    for (unsigned int clear = 0; clear < bufSize; clear++) {
        buf[clear] = 0;
    }
    byteCount++;
    /*increment byte size-- where do we declare a total byte size- in hpp?? if
     * so, is this what would be incremented?*/
}

/**
 * TODO: Write the least significant bit of the given int to the bit buffer.
 * Flushes the buffer first if it is full (which means all the bits in the
 * buffer have already been set). You may assume the given int is either 0 or 1.
 */
void BitOutputStream::writeBit(unsigned int i) {
    /*everything is read, fill the buffer first*/
    if ((byteCount == bufSize) || (nbits % 8 == 0 && nbits > 0)) {
        flush();
    }

    /*opposite of writeBit */
    int bitIndex = nbits % 8;

    int byteIndex = nbits / 8;

    buf[byteIndex] = (buf[byteIndex] | i << (7 - bitIndex));
    nbits++;
}
